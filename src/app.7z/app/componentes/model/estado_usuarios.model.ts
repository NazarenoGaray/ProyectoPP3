export class estado_usuarios {
    constructor(
      public id_estado_usuario: number,
      public estado: string
    ) {}
  }
  