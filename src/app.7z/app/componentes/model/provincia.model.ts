export interface Provincia {
    IDProvincia: number;
    Descripcion: string;
    // Otras propiedades del modelo
  }
  