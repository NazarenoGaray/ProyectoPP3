export interface Localidad {
    IDLocalidad: number;
    Descripcion: string;
    // Otras propiedades del modelo
  }
  