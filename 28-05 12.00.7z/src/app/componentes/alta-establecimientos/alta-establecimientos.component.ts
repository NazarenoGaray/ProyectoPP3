import { Component } from '@angular/core';

@Component({
  selector: 'app-alta-establecimientos',
  templateUrl: './alta-establecimientos.component.html',
  styleUrls: ['./alta-establecimientos.component.css']
})
export class AltaEstablecimientosComponent {

}
