import { Component } from '@angular/core';

@Component({
  selector: 'app-bienvenido2',
  templateUrl: './bienvenido2.component.html',
  styleUrls: ['./bienvenido2.component.css']
})
export class Bienvenido2Component {

}
