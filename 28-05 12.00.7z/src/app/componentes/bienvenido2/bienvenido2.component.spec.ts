import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Bienvenido2Component } from './bienvenido2.component';

describe('Bienvenido2Component', () => {
  let component: Bienvenido2Component;
  let fixture: ComponentFixture<Bienvenido2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Bienvenido2Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Bienvenido2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
