export interface Sector {
  id_sector: number;
  nombre: string;
  ubicacion: string;
}
