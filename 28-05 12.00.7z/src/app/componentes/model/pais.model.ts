export interface Pais {
    IDPais: number;
    Descripcion: string;
    // Otras propiedades del modelo
  }
  