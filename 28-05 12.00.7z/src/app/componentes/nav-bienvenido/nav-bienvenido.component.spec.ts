import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NavBienvenidoComponent } from './nav-bienvenido.component';

describe('NavBienvenidoComponent', () => {
  let component: NavBienvenidoComponent;
  let fixture: ComponentFixture<NavBienvenidoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NavBienvenidoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NavBienvenidoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
