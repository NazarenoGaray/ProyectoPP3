import { Component } from '@angular/core';

@Component({
  selector: 'app-nav-bienvenido',
  templateUrl: './nav-bienvenido.component.html',
  styleUrls: ['./nav-bienvenido.component.css']
})
export class NavBienvenidoComponent {

}
