<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: GET,POST");
header("Content-Type: application/json; charset=UTF-8");

require_once 'conexionBD.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
  header('Access-Control-Allow-Origin: *');
  header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
  header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');
  exit;
}


// Variables para la conexión
$host = "localhost";
$dbname = "tppp3";
$username = "root";
$password = "";


// Función para obtener todos los usuarios
function getUsuarios($conexion){
  $stmt = $conexion->query("SELECT * FROM usuarios");
  $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
  return $usuarios;
}

// Función para obtener un usuario por su ID
function getUsuarioPorId($conexion, $id_usuario){
  $stmt = $conexion->prepare("SELECT * FROM usuarios WHERE id_usuario = ?");
  $stmt->execute([$id_usuario]);
  $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
  return $usuario;
}

// Función para crear un nuevo usuario
function crearUsuario($conexion, $datos_usuario){
  $stmt = $conexion->prepare("INSERT INTO usuarios (nombre, apellido, direccion, telefono, correo, usuario, contrasena, id_rol, IDPais, IDProvincia, IDLocalidad, id_estado_usuario) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
  
  $result = $stmt->execute([
    $datos_usuario['nombre'],
    $datos_usuario['apellido'],
    $datos_usuario['direccion'],
    $datos_usuario['telefono'],
    $datos_usuario['correo'],
    $datos_usuario['usuario'],
    $datos_usuario['contrasena'],
    $datos_usuario['id_rol'],
    $datos_usuario['pais'],
    $datos_usuario['provincia'],
    $datos_usuario['localidad'],
    $datos_usuario['id_estado_usuario']
  ]);
  // verificar si se ejecutó la consulta correctamente
  if (!$result) {
    error_log('Error al insertar usuario: ' . print_r($stmt->errorInfo(), true));
    return false;
  }

  return $conexion->lastInsertId();
}




function actualizarUsuario($conexion, $id_usuario, $datos_usuario)
{
  //$stmt = $conexion->prepare("UPDATE usuarios SET nombre = ?, apellido = ?, telefono = ?, correo = ?, direccion = ?, usuario = ?, contrasena = ?, IDPais = ?, IDProvincia = ?, IDLocalidad = ?, id_rol = ?, id_estado_usuario = ? WHERE id_usuario = ?");
  
  // Obtener los campos del usuario a actualizar
  $nombre = $datos_usuario['nombre'];
  $apellido = $datos_usuario['apellido'];
  $telefono = $datos_usuario['telefono'];
  $correo = $datos_usuario['correo'];
  $direccion = $datos_usuario['direccion'];
  $usuario = $datos_usuario['usuario'];
  $contrasena = $datos_usuario['contrasena'];
  $IDPais = $datos_usuario['pais'];
  $IDProvincia = $datos_usuario['provincia'];
  $IDLocalidad = $datos_usuario['localidad'];
  $id_rol = $datos_usuario['id_rol'];
  $id_estado_usuario = $datos_usuario['id_estado_usuario'];
  
  // Actualizar el usuario en la base de datos
  $stmt = $conexion->prepare("UPDATE usuarios
      SET nombre = :nombre, apellido = :apellido, direccion = :direccion, telefono = :telefono, correo = :correo, usuario = :usuario, contrasena = :contrasena, id_rol = :id_rol, IDPais = :Pais, IDProvincia = :provincia, IDLocalidad = :Localidad, id_estado_usuario = :id_estado_usuario
      WHERE id_usuario = :id_usuario");

  $stmt->bindParam(':nombre', $nombre);
  $stmt->bindParam(':apellido', $apellido);
  $stmt->bindParam(':direccion', $direccion);
  $stmt->bindParam(':telefono', $telefono);
  $stmt->bindParam(':correo', $correo);
  $stmt->bindParam(':usuario', $usuario);
  $stmt->bindParam(':contrasena', $contrasena);
  $stmt->bindParam(':id_rol', $id_rol);
  $stmt->bindParam(':pais', $IDLocalidad);
  $stmt->bindParam(':provincia', $IDLocalidad);
  $stmt->bindParam(':localidad', $IDLocalidad);
  $stmt->bindParam(':id_estado_usuario', $id_estado_usuario);
  $stmt->bindParam(':id_usuario', $id_usuario);

  $stmt->execute();
  // $stmt->execute([
  //   $nombre,
  //   $apellido,
  //   $telefono,
  //   $correo,
  //   $direccion,
  //   $usuario,
  //   $contrasena,
  //   $IDPais,
  //   $IDProvincia,
  //   $IDLocalidad,
  //   $id_rol,
  //   $id_estado_usuario,
  //   $id_usuario
  // ]);
}



function eliminarUsuario($conexion, $id_usuario)
{
  $stmt = $conexion->prepare("DELETE FROM usuarios WHERE id_usuario = ?");
  $stmt->execute([$id_usuario]);
}

// Obtiene la acción que se va a realizar (get, post, put o delete)
$accion = $_SERVER['REQUEST_METHOD'];

// Obtiene el ID del usuario (si es necesario)
$id_usuario = isset($_GET['id_usuario']) ? $_GET['id_usuario'] : null;

// Realiza la acción correspondiente

switch ($accion) {
  case 'GET':
    global $conexion;
    if ($id_usuario) {
      // Obtiene un usuario por su ID
      $usuario = getUsuarioPorId($conexion, $id_usuario);
      echo json_encode($usuario);
    } else {
      
      // Obtiene todos los usuarios
      $usuarios = getUsuarios($conexion);
      echo json_encode($usuarios);
    }
    break;
  case 'POST':
    global $conexion;
    // Crea un nuevo usuario
    $datos_usuario = json_decode(file_get_contents('php://input'), true);
    $id_usuario_creado = crearUsuario($conexion, $datos_usuario);
    echo json_encode(['id_usuario' => $id_usuario_creado]);
    break;
    case 'PUT':
      global $conexion;
      // Obtener los datos enviados por el cliente
      $datos_usuario = json_decode(file_get_contents('php://input'), true);
      
      // Obtener los campos del usuario a actualizar
      $id_usuario = $datos_usuario['id_usuario'];
      // $nombre = $datos_usuario['nombre'];
      // $apellido = $datos_usuario['apellido'];
      // $direccion = $datos_usuario['direccion'];
      // $telefono = $datos_usuario['telefono'];
      // $correo = $datos_usuario['correo'];
      // $usuario = $datos_usuario['usuario'];
      // $contrasena = $datos_usuario['contrasena'];
      // $id_rol = $datos_usuario['id_rol'];
      // $IDLocalidad = $datos_usuario['IDLocalidad'];
      // $id_estado_usuario = $datos_usuario['id_estado_usuario'];
      actualizarUsuario($conexion, $id_usuario, $datos_usuario);

      // Actualizar el usuario en la base de datos
      // $stmt = $conexion->prepare("UPDATE usuarios
      //     SET nombre = :nombre, apellido = :apellido, direccion = :direccion, telefono = :telefono, correo = :correo, usuario = :usuario, contrasena = :contrasena, id_rol = :id_rol, IDLocalidad = :IDLocalidad, id_estado_usuario = :id_estado_usuario
      //     WHERE id_usuario = :id_usuario");
  
      // $stmt->bindParam(':nombre', $nombre);
      // $stmt->bindParam(':apellido', $apellido);
      // $stmt->bindParam(':direccion', $direccion);
      // $stmt->bindParam(':telefono', $telefono);
      // $stmt->bindParam(':correo', $correo);
      // $stmt->bindParam(':usuario', $usuario);
      // $stmt->bindParam(':contrasena', $contrasena);
      // $stmt->bindParam(':id_rol', $id_rol);
      // $stmt->bindParam(':IDLocalidad', $IDLocalidad);
      // $stmt->bindParam(':id_estado_usuario', $id_estado_usuario);
      // $stmt->bindParam(':id_usuario', $id_usuario);
  
      // $stmt->execute();
      break;
  
  case 'DELETE':
    global $conexion;
    // Elimina un usuario por su ID
    eliminarUsuario($conexion, $id_usuario);
    break;
  default:
    // Si se intenta realizar una acción no válida, devuelve un error 400
    http_response_code(400);
    echo json_encode(['error' => 'Acción no válida']);
    break;
}
