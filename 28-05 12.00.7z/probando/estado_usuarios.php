<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
require_once 'conexionBD.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');
    exit;
}

// Obtiene todos los estados de usuarios
function obtenerEstadosUsuarios()
{
    global $conexion;
    $query = "SELECT * FROM estado_usuarios";
    $statement = $conexion->prepare($query);
    $statement->execute();
    $result = $statement->fetchAll(PDO::FETCH_ASSOC);
    return $result;
}

// Obtiene un estado de usuario por su ID
function obtenerEstadoUsuarioPorId($id)
{
    global $conexion;
    $query = "SELECT * FROM estado_usuarios WHERE id_estado_usuario = :id";
    $statement = $conexion->prepare($query);
    $statement->bindParam(':id', $id);
    $statement->execute();
    $result = $statement->fetch(PDO::FETCH_ASSOC);
    return $result;
}

// Crea un nuevo estado de usuario
function crearEstadoUsuario($estadoUsuario)
{
    global $conexion;
    $query = "INSERT INTO estado_usuarios (estado) VALUES (:estado)";
    $statement = $conexion->prepare($query);
    $statement->bindParam(':estado', $estadoUsuario['estado']);
    $statement->execute();
    $id = $conexion->lastInsertId();
    $estadoUsuario['id_estado_usuario'] = $id;
    return $estadoUsuario;
}

// Actualiza un estado de usuario por su ID
function actualizarEstadoUsuario($id, $estadoUsuario)
{
    global $conexion;
    $query = "UPDATE estado_usuarios SET estado = :estado WHERE id_estado_usuario = :id";
    $statement = $conexion->prepare($query);
    $statement->bindParam(':id', $id);
    $statement->bindParam(':estado', $estadoUsuario['estado']);
    $statement->execute();
    return $estadoUsuario;
}

// Elimina un estado de usuario por su ID
function eliminarEstadoUsuario($id)
{
    global $conexion;
    $query = "DELETE FROM estado_usuarios WHERE id_estado_usuario = :id";
    $statement = $conexion->prepare($query);
    $statement->bindParam(':id', $id);
    $statement->execute();
    return true;
}

// Rutas de la API
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $estadoUsuario = obtenerEstadoUsuarioPorId($id);
        echo json_encode($estadoUsuario);
    } else {
        $estadosUsuarios = obtenerEstadosUsuarios();
        echo json_encode($estadosUsuarios);
    }
} else if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $estadoUsuario = json_decode(file_get_contents('php://input'), true);
    $estadoUsuarioCreado = crearEstadoUsuario($estadoUsuario);
    echo json_encode($estadoUsuarioCreado);
} else if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
    parse_str(file_get_contents("php://input"), $put_vars);
    $id = $put_vars['id'];
    $estadoUsuario = json_decode(file_get_contents('php://input'), true);
    $estadoUsuarioActualizado = actualizarEstadoUsuario($id, $estadoUsuario);
    echo json_encode($estadoUsuarioActualizado);
} else if ($_SERVER['REQUEST_METHOD'] == 'DELETE') {
    parse_str(file_get_contents("php://input"), $delete_vars);
    $id = $delete_vars['id'];
    eliminarEstadoUsuario($id);
    echo json_encode(true);
}
