<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
require_once 'conexionBD.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');
    exit;
}

// Obtiene todas las localidades
function obtenerLocalidadesPorProvincia($conexion,$idProvincia)
{
    $query = "SELECT * FROM localidades WHERE IDProvincia = :idProvincia";
    $statement = $conexion->prepare($query);
    $statement->bindParam(':idProvincia', $idProvincia);
    $statement->execute();
    $result = $statement->fetchAll(PDO::FETCH_ASSOC);
    return $result;
}

// Obtiene una localidad por su ID
function obtenerLocalidadPorId($conexion,$id)
{
    $query = "SELECT * FROM localidades WHERE IDLocalidad = :id";
    $statement = $conexion->prepare($query);
    $statement->bindParam(':id', $id);
    $statement->execute();
    $result = $statement->fetch(PDO::FETCH_ASSOC);
    return $result;
}

// Rutas de la API
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    global $conexion;
    if (isset($_GET['IDProvincia'])) {
        $idProvincia = $_GET['IDProvincia'];
        $localidades = obtenerLocalidadesPorProvincia($conexion,$idProvincia);
        echo json_encode($localidades);
    } //else {
    //     $localidades = obtenerLocalidades();
    //     echo json_encode($localidades);
    // }
}
