<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: GET,POST");
header("Content-Type: application/json; charset=UTF-8");



if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
  header('Access-Control-Allow-Origin: *');
  header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
  header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');
  exit;
}


// Variables para la conexión
$host = "localhost";
$dbname = "tppp3";
$username = "root";
$password = "";

// Intenta conectarse a la base de datos
try {
  $conexion = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
  // Configura el modo de error de PDO a excepciones
  $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
  // En caso de error, muestra el mensaje de error y detiene el script
  die("Error al conectarse a la base de datos: " . $e->getMessage());
}
require __DIR__ . '/vendor/autoload.php';

use vendor\firebase\JWT\JWT;

$accion = $_SERVER['REQUEST_METHOD'];

/*
Funcion para generar el token
*/

// Función para validar las credenciales del usuario
function validarCredenciales($conexion, $usuario, $contrasena) {
  // Preparamos la consulta SQL para buscar el usuario y la contraseña en la tabla de usuarios
  $consulta = "SELECT usuarios.id_usuario , usuarios.id_rol, rol.rol 
  FROM usuarios
  INNER JOIN rol ON usuarios.id_rol = rol.id_rol
  WHERE usuario = '" . $usuario . "' AND contrasena = '" . $contrasena . "'";
  $resultado = $conexion->query($consulta);

  // Verificamos si hubo un error en la consulta
  if (!$resultado) {
    http_response_code(500); // Internal Server Error
    echo "Error en la consulta a la base de datos: " . $conexion->error;
    return false;
  }
  // Obtenemos el primer resultado de la consulta
  $aux = $resultado->fetch();
  //echo json_encode($aux);
  //$id_usuario = array("id_usuario" => $aux["id_usuario"]);
  
  // Devolvemos el nuevo array en formato JSON
  //echo json_encode(array("id" => $id_usuario));
  return $aux;
}

function generarToken($usuario,$id_usuario,$id_rol,$rol){
  $time = time();

  $token = array(
    "iat"=> $time, //tiempo presente
    "exp" => $time *(60*30),// tiempo de vida del token (segundos*minutos*horas*dias)
    "data"=> [
      "id" => $id_usuario,
      "usuario"=> $usuario,
      "id_rol"=>$id_rol,
      "rol"=>$rol
    ]
  );
  return $token;
}
if($accion = 'POST'){
  $login_usuario = json_decode(file_get_contents('php://input'), true);
  $usuario = $login_usuario['usuario'];
  $contrasena = $login_usuario['contrasena'];
  //echo json_encode($usuario);
  //echo json_encode($contrasena);
  $datos = validarCredenciales($conexion, $usuario, $contrasena);
  
  if ($datos != Null) {
    // Generar un token de acceso y devolverlo en la respuesta
    //echo json_encode(array("datos" => $datos));
    $token = generarToken($usuario,$datos['id_usuario'],$datos['id_rol'],$datos['rol']);
    echo json_encode(array("token" => $token));
    //echo json_encode(array("id" => $id));
    //echo "Usuario correcto";
  }else{
  http_response_code(401); // Unauthorized
  echo "Nombre de usuario o contraseña incorrectosss";
  }
}else{
// Si se intenta realizar una acción no válida, devuelve un error 400
  http_response_code(400);
  echo json_encode(array("error" => "Acción no válida en el switch de apiLogin"));
}


