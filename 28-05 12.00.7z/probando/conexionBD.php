<?php
// Variables para la conexión
$host = "localhost";
$dbname = "tppp3";
$username = "root";
$password = "";

// Intenta conectarse a la base de datos
try {
  $conexion = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
  // Configura el modo de error de PDO a excepciones
  $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
  // En caso de error, muestra el mensaje de error y detiene el script
  die("Error al conectarse a la base de datos: " . $e->getMessage());
}

?>