<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
require_once 'conexionBD.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');
    exit;
  }
  
// Obtiene todos los roles
function obtenerRoles() {
    global $conexion;
    $query = "SELECT * FROM rol";
    $statement = $conexion->prepare($query);
    $statement->execute();
    $result = $statement->fetchAll(PDO::FETCH_ASSOC);
    return $result;
}

// Obtiene un rol por su ID
function obtenerRolPorId($id) {
    global $conexion;
    $query = "SELECT * FROM rol WHERE id_rol = :id";
    $statement = $conexion->prepare($query);
    $statement->bindParam(':id', $id);
    $statement->execute();
    $result = $statement->fetch(PDO::FETCH_ASSOC);
    return $result;
}

// Crea un nuevo rol
function crearRol($rol) {
    global $conexion;
    $query = "INSERT INTO rol (nombre, descripcion) VALUES (:nombre, :descripcion)";
    $statement = $conexion->prepare($query);
    $statement->bindParam(':nombre', $rol['nombre']);
    $statement->bindParam(':descripcion', $rol['descripcion']);
    $statement->execute();
    $id = $conexion->lastInsertId();
    $rol['id'] = $id;
    return $rol;
}

// Actualiza un rol por su ID
function actualizarRol($id, $rol) {
    global $conexion;
    $query = "UPDATE rol SET nombre = :nombre, descripcion = :descripcion WHERE id_rol = :id";
    $statement = $conexion->prepare($query);
    $statement->bindParam(':id', $id);
    $statement->bindParam(':nombre', $rol['nombre']);
    $statement->bindParam(':descripcion', $rol['descripcion']);
    $statement->execute();
    return $rol;
}

// Elimina un rol por su ID
function eliminarRol($id) {
    global $conexion;
    $query = "DELETE FROM rol WHERE id_rol = :id";
    $statement = $conexion->prepare($query);
    $statement->bindParam(':id', $id);
    $statement->execute();
    return true;
}

// Rutas de la API
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $rol = obtenerRolPorId($id);
        echo json_encode($rol);
    } else {
        $roles = obtenerRoles();
        echo json_encode($roles);
    }
} else if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $rol = json_decode(file_get_contents('php://input'), true);
    $rolCreado = crearRol($rol);
    echo json_encode($rolCreado);
} else if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
    parse_str(file_get_contents("php://input"), $put_vars);
    $id = $put_vars['id'];
    $rol = json_decode(file_get_contents('php://input'), true);
    $rolActualizado = actualizarRol($id, $rol);
    echo json_encode($rolActualizado);
} else if ($_SERVER['REQUEST_METHOD'] == 'DELETE') {
    parse_str(file_get_contents("php://input"), $delete_vars);
    $id = $delete_vars['id'];
    eliminarRol($id);
    echo json_encode(true);
}

?>