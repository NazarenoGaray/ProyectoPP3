<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
require_once 'conexionBD.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');
    exit;
}

// Obtiene todas las provincias
function obtenerProvinciasPorPais($conexion,$idPais) {
    $query = "SELECT * FROM provincias WHERE IDPais = :IDPais";
    $statement = $conexion->prepare($query);
    $statement->bindParam(':IDPais', $idPais);
    $statement->execute();
    $result = $statement->fetchAll(PDO::FETCH_ASSOC);
    return $result;
}

// Obtiene una provincia por su ID
function obtenerProvinciaPorId($conexion,$id) {
    $query = "SELECT * FROM provincias WHERE IDProvincia = :idProvincia";
    $statement = $conexion->prepare($query);
    $statement->bindParam(':idProvincia', $id);
    $statement->execute();
    $result = $statement->fetch(PDO::FETCH_ASSOC);
    return $result;
}
function obtenerProvincias(){
    $query = "SELECT * FROM provincias";
    $statement = $conexion->prepare($query);
    $statement->execute();
    $result = $statement->fetchAll(PDO::FETCH_ASSOC);
    return $result;
}
// Rutas de la API
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    global $conexion;
    if (isset($_GET['IDPais'])) {
        $idPais = $_GET['IDPais'];
        $provincias = obtenerProvinciasPorPais($conexion,$idPais);
        echo json_encode($provincias);
    }//if(isset($_GET['idProvincia'])){
    //     $idProvincia = $_GET['idProvincia'];
    //     $provincias = obtenerProvinciaPorId($conexion,$idProvincia);
    //     echo json_encode($provincias);
    // } else {
    //    $provincias = obtenerProvincias($conexion);
    //    echo json_encode($provincias);
    // }
}
?>
