<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: GET, POST");
header("Content-Type: application/json; charset=UTF-8");

require_once 'conexionBD.php';

// Permitir CORS y métodos HTTP
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');
    exit;
}

// Obtener todos los establecimientos con nombres de país, provincia, localidad y nombre de establecimiento
if ($_SERVER['REQUEST_METHOD'] === 'GET' && empty($_GET)) {
    // Consulta SQL para obtener los establecimientos con información adicional
    // Puedes personalizar la consulta según tus necesidades
    $query = 'SELECT e.id_establecimiento,
    e.nombreEstablecimiento,
    p.Descripcion AS nombrePais,
    pr.Descripcion AS nombreProvincia,
    l.Descripcion AS nombreLocalidad,
    e.calle,
    e.altura
    FROM establecimientos AS e
    INNER JOIN paises AS p ON e.idPais = p.idPais
    INNER JOIN provincias AS pr ON e.idProvincia = pr.idProvincia
    INNER JOIN localidades AS l ON e.idLocalidad = l.idLocalidad';

    $stmt = $conexion->query($query);
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($result);
}

// Obtener todos los países
if (isset($_GET['paises'])) {
    // Consulta SQL para obtener todos los países
    $query = 'SELECT * FROM paises';
    $stmt = $conexion->prepare($query);
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($result);
    exit();
}

// Recuperar un país según su ID
if (isset($_GET['pais']) && isset($_GET['idPais'])) {
    // Obtener el ID del país desde los parámetros de la URL
    $idPais = $_GET['idPais'];

    // Consulta SQL para obtener el país por ID
    $query = 'SELECT * FROM paises WHERE IDPais = ?';
    $stmt = $conexion->prepare($query);
    $stmt->execute([$idPais]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    echo json_encode($result);
    exit();
}

// Obtener provincias según el ID del país
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['idPais'])) {
    // Obtener el ID del país desde los parámetros de la URL
    $idPais = $_GET['idPais'];

    // Consulta SQL para obtener las provincias por el ID del país
    $stmt = $conexion->prepare('SELECT * FROM provincias WHERE IDPais = ?');
    $stmt->execute([$idPais]);
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($result);
}

// Obtener localidades según el ID de la provincia
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['idProvincia'])) {
    // Obtener el ID de la provincia desde los parámetros de la URL
    $idProvincia = $_GET['idProvincia'];

    // Consulta SQL para obtener las localidades por el ID de la provincia
    $stmt = $conexion->prepare('SELECT * FROM localidades WHERE IdProvincia = ?');
    $stmt->execute([$idProvincia]);
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($result);
}

// Obtener establecimiento por ID
if (isset($_GET['id_establecimiento'])) {
    // Obtener el ID del establecimiento desde los parámetros de la URL
    $idEstablecimiento = $_GET['id_establecimiento'];

    // Consulta SQL para obtener el establecimiento por ID con información adicional
    // Puedes personalizar la consulta según tus necesidades
    $query = 'SELECT e.id_establecimiento,
    e.nombreEstablecimiento,
    p.Descripcion AS nombrePais,
    pr.Descripcion AS nombreProvincia,
    l.Descripcion AS nombreLocalidad,
    e.calle,
    e.altura,
    e.horario_entrada,
    e.horario_salida,
    e.telefono,
    e.correo
    FROM establecimientos AS e
    INNER JOIN paises AS p ON e.idPais = p.idPais
    INNER JOIN provincias AS pr ON e.idProvincia = pr.idProvincia
    INNER JOIN localidades AS l ON e.idLocalidad = l.idLocalidad
    WHERE e.id_establecimiento = ?';

    $stmt = $conexion->prepare($query);
    $stmt->execute([$idEstablecimiento]);
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($result);
    exit();
}

// Crear un nuevo establecimiento
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtener los datos del establecimiento del cuerpo de la solicitud
    $data = json_decode(file_get_contents('php://input'), true);
    $idEstablecimiento = $data['idEstablecimiento'];
    $nombreEstablecimiento = $data['nombreEstablecimiento'];
    $IdPais = $data['IdPais'];
    $IdProvincia = $data['IdProvincia'];
    $IdLocalidad = $data['IdLocalidad'];
    $calle = $data['calle'];
    $altura = $data['altura'];

    // Consulta SQL para insertar un nuevo establecimiento en la base de datos
    $stmt = $conexion->prepare('INSERT INTO establecimientos (id_establecimiento, nombreEstablecimiento, idPais, idProvincia, idLocalidad, calle, altura) VALUES (?, ?, ?, ?, ?, ?, ?)');
    $stmt->execute([$idEstablecimiento, $nombreEstablecimiento, $IdPais, $IdProvincia, $IdLocalidad, $calle, $altura]);

    // Devolver respuesta en formato JSON
    $response = array('message' => 'Establecimiento creado exitosamente');
    echo json_encode($response);
}

// Actualizar un establecimiento existente
if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    // Obtener los datos del establecimiento del cuerpo de la solicitud
    $data = json_decode(file_get_contents('php://input'), true);
    $idEstablecimiento = $data['idEstablecimiento'];
    $IdPais = $data['IdPais'];
    $IdProvincia = $data['IdProvincia'];
    $IdLocalidad = $data['IdLocalidad'];
    $calle = $data['calle'];
    $altura = $data['altura'];

    // Consulta SQL para actualizar un establecimiento existente en la base de datos
    $stmt = $conexion->prepare('UPDATE establecimientos SET idPais=?, idProvincia=?, idLocalidad=?, calle=?, altura=? WHERE id_establecimiento=?');
    $stmt->execute([$IdPais, $IdProvincia, $IdLocalidad, $calle, $altura, $idEstablecimiento]);
    echo 'Establecimiento actualizado exitosamente';
}

// Eliminar un establecimiento existente
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    // Obtener el ID del establecimiento desde los datos enviados en el cuerpo de la solicitud
    $data = json_decode(file_get_contents('php://input'), true);
    $idEstablecimiento = $data['idEstablecimiento'];

    // Consulta SQL para eliminar un establecimiento existente de la base de datos
    $stmt = $conexion->prepare('DELETE FROM establecimientos WHERE id_establecimiento=?');
    $stmt->execute([$idEstablecimiento]);
    echo 'Establecimiento eliminado exitosamente';
}

?>
