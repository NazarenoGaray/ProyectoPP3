<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
require_once 'conexionBD.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');
    exit;
}

// Obtiene todas las provincias
function obtenerPaises() {
    global $conexion;
    $query = "SELECT * FROM paises";
    $statement = $conexion->prepare($query);
    $statement->execute();
    $result = $statement->fetchAll(PDO::FETCH_ASSOC);
    return $result;
}

// Obtiene una provincia por su ID
function obtenerPaisPorId($id) {
    global $conexion;
    $query = "SELECT * FROM paises WHERE IDPais = :id";
    $statement = $conexion->prepare($query);
    $statement->bindParam(':id', $id);
    $statement->execute();
    $result = $statement->fetch(PDO::FETCH_ASSOC);
    return $result;
}

// Rutas de la API
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $pais = obtenerPaisPorId($id);
        echo json_encode($pais);
    } else {
        $paises = obtenerPaises();
        echo json_encode($paises);
    }
}
?>