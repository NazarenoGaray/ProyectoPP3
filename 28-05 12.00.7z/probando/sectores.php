<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: GET, POST");
header("Content-Type: application/json; charset=UTF-8");

require_once 'conexionBD.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');
    exit;
}

// Obtener todos los sectores
if ($_SERVER['REQUEST_METHOD'] === 'GET' && empty($_GET)) {
    $query = 'SELECT * FROM sectores';
    $stmt = $conexion->query($query);
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($result);
}

// Obtener un sector por ID
if (isset($_GET['id_sector'])) {
    $idSector = $_GET['id_sector'];

    $query = 'SELECT * FROM sectores WHERE id_sector = ?';
    $stmt = $conexion->prepare($query);
    $stmt->execute([$idSector]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    echo json_encode($result);
    exit();
}

// Obtener el nombre del sector correspondiente a un establecimiento
if (isset($_GET['id_establecimiento'])) {
    $idEstablecimiento = $_GET['id_establecimiento'];

    $query = 'SELECT s.nombre
    FROM sectores AS s
    INNER JOIN sectores_establecimientos AS se ON s.Id_sector = se.fk_Id_sector
    WHERE se.fk_id_establecimiento = ?';

    $stmt = $conexion->prepare($query);
    $stmt->execute([$idEstablecimiento]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    echo json_encode($result);
    exit();
}



// Asociar un establecimiento a un sector
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $idEstablecimiento = $data['idEstablecimiento'];
    $idSector = $data['idSector'];

    $stmt = $conexion->prepare('INSERT INTO establecimientos_sectores (id_establecimiento, id_sector) VALUES (?, ?)');
    $stmt->execute([$idEstablecimiento, $idSector]);

    // Devolver respuesta en formato JSON
    $response = array('message' => 'Establecimiento asociado al sector exitosamente');
    echo json_encode($response);
}

// Desasociar un establecimiento de un sector
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    $data = json_decode(file_get_contents('php://input'), true);
    $idEstablecimiento = $data['idEstablecimiento'];
    $idSector = $data['idSector'];

    $stmt = $conexion->prepare('DELETE FROM establecimientos_sectores WHERE id_establecimiento = ? AND id_sector = ?');
    $stmt->execute([$idEstablecimiento, $idSector]);
    echo 'Establecimiento desasociado del sector exitosamente';
}
?>
